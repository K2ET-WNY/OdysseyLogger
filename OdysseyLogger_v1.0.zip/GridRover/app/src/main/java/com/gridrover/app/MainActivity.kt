package com.gridrover.app

import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.PinDrop
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Looper
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.gms.location.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        // 1. Initialize the Splash Screen API
        installSplashScreen()

        // 2. Call the super method AFTER the splash screen is installed
        super.onCreate(savedInstanceState)

        // 3. Build your Compose UI
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF00E676), // Neon green
                    background = Color(0xFF121212),
                    surface = Color(0xFF1E1E1E)
                )
            ) {
                MainScreenShell()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("MissingPermission")
@Composable
fun MainScreenShell() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var currentTab by remember { mutableStateOf(0) }

    var liveGridSquare by remember { mutableStateOf("WAITING") }
    var currentLatitude by remember { mutableStateOf(0.0) }
    var currentLongitude by remember { mutableStateOf(0.0) }

    val database = remember { AppDatabase.getDatabase(context) }
    val logDao = database.logDao()

    val loggedContacts by logDao.getAllLogs().collectAsState(initial = emptyList())
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    val sharedPrefs = remember { context.getSharedPreferences("GridRoverPrefs", Context.MODE_PRIVATE) }
    var activeContest by remember { mutableStateOf(sharedPrefs.getString("active_contest", "ARRL June VHF Contest") ?: "ARRL June VHF Contest") }

    var scatterSubScreen by remember { mutableStateOf("menu") }
    var toolboxSubScreen by remember { mutableStateOf("menu") }
    var sharedStormGrid by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        liveGridSquare = if (isGranted) "SEARCHING" else "NO PERM"
    }

    LaunchedEffect(Unit) {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000).build()
            val locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    val lastLocation = locationResult.lastLocation ?: return
                    currentLatitude = lastLocation.latitude
                    currentLongitude = lastLocation.longitude
                    liveGridSquare = convertToGridSquare(lastLocation.latitude, lastLocation.longitude)
                }
            }
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
        } else {
            permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    LaunchedEffect(currentTab) {
        activeContest = sharedPrefs.getString("active_contest", "ARRL June VHF Contest") ?: "ARRL June VHF Contest"
        if (currentTab != 1) scatterSubScreen = "menu"
        if (currentTab != 3) toolboxSubScreen = "menu"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(end = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if ((currentTab == 1 && scatterSubScreen != "menu") || (currentTab == 3 && toolboxSubScreen != "menu")) {
                                IconButton(onClick = {
                                    if (currentTab == 1) scatterSubScreen = "menu"
                                    if (currentTab == 3) toolboxSubScreen = "menu"
                                }) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Column {
                                Text("ODYSSEY LOGGER", fontWeight = FontWeight.Bold, letterSpacing = 1.sp, fontSize = 18.sp)
                                val subTitle = when (currentTab) {
                                    1 -> if (scatterSubScreen == "menu") "Scatter Menu" else if (scatterSubScreen == "map") "Live Radar View" else "Vector Calculator"
                                    2 -> "Station Settings"
                                    3 -> when (toolboxSubScreen) {
                                        "menu" -> "RF Toolbox"
                                        "dipole" -> "Dipole Length Calc"
                                        "coax" -> "Coax Loss Calc"
                                        "feedhorn" -> "Dish Focal Length"
                                        "ifcalc" -> "Transverter IF Math"
                                        else -> "Toolbox"
                                    }
                                    else -> activeContest
                                }
                                Text(subTitle, color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        Box(modifier = Modifier.background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text(text = liveGridSquare.take(6), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Assignment, contentDescription = "Logbook") },
                    label = { Text("Logging") }
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(Icons.Default.Radar, contentDescription = "Scatter") },
                    label = { Text("Scatter") }
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Station") },
                    label = { Text("Station") }
                )
                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = { currentTab = 3 },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Toolbox") },
                    label = { Text("Toolbox") }
                )
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues).background(MaterialTheme.colorScheme.background)) {
            val contextSpecificContacts = loggedContacts.filter { it.selectedContest == activeContest }
            when (currentTab) {
                0 -> LoggingDashboard(
                    activeContest = activeContest,
                    liveGrid = liveGridSquare,
                    myLat = currentLatitude,
                    myLon = currentLongitude,
                    contactsList = contextSpecificContacts,
                    onSaveContact = { entry -> scope.launch { logDao.insertLog(entry) } },
                    onDeleteContact = { contact -> scope.launch { logDao.deleteLog(contact) } }
                )
                1 -> ScatterMasterRouter(
                    subScreen = scatterSubScreen,
                    myLat = currentLatitude,
                    myLon = currentLongitude,
                    myGrid = liveGridSquare,
                    sharedStormGrid = sharedStormGrid,
                    onSharedGridChanged = { sharedStormGrid = it },
                    onNavigate = { scatterSubScreen = it }
                )
                2 -> SettingsTabScreen(
                    contactsList = contextSpecificContacts,
                    activeContest = activeContest,
                    onContestChanged = { activeContest = it }
                )
                3 -> ToolboxMasterRouter(
                    subScreen = toolboxSubScreen,
                    onNavigate = { toolboxSubScreen = it }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LoggingDashboard(
    activeContest: String,
    liveGrid: String,
    myLat: Double,
    myLon: Double,
    contactsList: List<LogEntry>,
    onSaveContact: (LogEntry) -> Unit,
    onDeleteContact: (LogEntry) -> Unit
) {
    val context = LocalContext.current
    val sharedPrefs = remember { context.getSharedPreferences("GridRoverPrefs", Context.MODE_PRIVATE) }

    var callSignInput by remember { mutableStateOf("") }
    val allowedBands: List<String> = remember(activeContest) { getFilteredBands(activeContest) }
    var selectedBand by remember(activeContest) { mutableStateOf(allowedBands.firstOrNull() ?: "2m") }
    var bandDropdownExpanded by remember { mutableStateOf(false) }

    var selectedMode by remember { mutableStateOf("PH") }
    var modeDropdownExpanded by remember { mutableStateOf(false) }
    val weakSignalModes = listOf("PH", "DIG", "FM", "AM", "CW")

    var gridRxInput by remember { mutableStateOf("") }

    var manualDateInput by remember { mutableStateOf("") }
    var manualTimeInput by remember { mutableStateOf("") }

    var rstSentInput by remember { mutableStateOf("59") }
    var rstRxInput by remember { mutableStateOf("59") }

    var contactActionTarget by remember { mutableStateOf<LogEntry?>(null) }
    var showActionDialog by remember { mutableStateOf(false) }

    val utcFormatter = remember { SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") } }

    val isContestMode = !activeContest.contains("General") && !activeContest.contains("Parks on the Air")
    val maxGridChars = if (activeContest.contains("10 GHz")) 6 else 4

    val quickBearing = remember(gridRxInput, myLat, myLon) {
        if (gridRxInput.length >= 4) {
            val (targetLat, targetLon) = parseMaidenhead(gridRxInput)
            if (targetLat != null && targetLon != null) {
                "${calculateBearing(myLat, myLon, targetLat, targetLon)}°"
            } else "---°"
        } else "---°"
    }

    val isDuplicateEntry = remember(callSignInput, gridRxInput, selectedBand, contactsList, liveGrid) {
        if (callSignInput.isBlank() || (isContestMode && gridRxInput.length < 4)) false else {
            val myClass = sharedPrefs.getString("class", "ROVER") ?: "ROVER"
            val amIRover = myClass.contains("Rover")
            val isTargetRover = callSignInput.endsWith("/R")

            contactsList.any { log ->
                val callsMatch = log.callSign == callSignInput
                val bandsMatch = log.band == selectedBand
                if (callsMatch && bandsMatch) {
                    if (isContestMode) {
                        when {
                            amIRover -> log.gridsquare.take(maxGridChars) == liveGrid.take(maxGridChars)
                            isTargetRover -> log.gridRx.take(maxGridChars) == gridRxInput.take(maxGridChars)
                            else -> true
                        }
                    } else {
                        true
                    }
                } else false
            }
        }
    }

    val computedScoreText = remember(contactsList, activeContest) {
        calculateLiveScore(contactsList, activeContest, sharedPrefs.getString("class", "ROVER") ?: "ROVER")
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(if (isContestMode) "LIVE ESTIMATED SCORE" else "SESSION LOG SUMMARY", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(text = computedScoreText.first, color = Color(0xFF00E676), fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
                Text(
                    text = computedScoreText.second,
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.End,
                    lineHeight = 14.sp
                )
            }
        }

        OutlinedTextField(
            value = callSignInput,
            onValueChange = { callSignInput = it.uppercase().trim() },
            label = { Text("Station Call Sign") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.weight(1f)) {
                ExposedDropdownMenuBox(
                    expanded = bandDropdownExpanded,
                    onExpandedChange = { bandDropdownExpanded = !bandDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedBand,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Band") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bandDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    ExposedDropdownMenu(expanded = bandDropdownExpanded, onDismissRequest = { bandDropdownExpanded = false }) {
                        allowedBands.forEach { bandOption ->
                            DropdownMenuItem(text = { Text(bandOption) }, onClick = { selectedBand = bandOption; bandDropdownExpanded = false })
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                ExposedDropdownMenuBox(
                    expanded = modeDropdownExpanded,
                    onExpandedChange = { modeDropdownExpanded = !modeDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedMode,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Mode") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modeDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    ExposedDropdownMenu(expanded = modeDropdownExpanded, onDismissRequest = { modeDropdownExpanded = false }) {
                        weakSignalModes.forEach { modeOption ->
                            DropdownMenuItem(text = { Text(modeOption) }, onClick = { selectedMode = modeOption; modeDropdownExpanded = false })
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (!isContestMode) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = rstSentInput,
                    onValueChange = { rstSentInput = it.uppercase().trim() },
                    label = { Text("RST Sent") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = rstRxInput,
                    onValueChange = { rstRxInput = it.uppercase().trim() },
                    label = { Text("RST Rx") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = manualDateInput,
                onValueChange = { manualDateInput = it.trim() },
                label = { Text("Date (YYYY-MM-DD)") },
                placeholder = { Text("Live Auto") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            OutlinedTextField(
                value = manualTimeInput,
                onValueChange = { manualTimeInput = it.trim() },
                label = { Text("Time (HH:mm) UTC") },
                placeholder = { Text("Live Auto") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = gridRxInput,
                onValueChange = {
                    if (it.length <= maxGridChars) {
                        gridRxInput = it.uppercase().trim().filter { c -> c.isLetterOrDigit() }
                    }
                },
                label = { Text(if (isContestMode) "Grid RX (${maxGridChars}-Char Max)" else "Grid RX (Optional)") },
                modifier = Modifier.weight(1.3f),
                singleLine = true
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.weight(0.7f).height(56.dp).padding(top = 4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("BEARING", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = quickBearing,
                        color = if (quickBearing != "---°") Color(0xFF00E676) else Color.DarkGray,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        if (isDuplicateEntry) {
            Spacer(modifier = Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F)), modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (isContestMode) "⚠️ DUPLICATE QSO IDENTIFIED FOR THIS BAND/GRID PROFILE" else "⚠️ STATION PREVIOUSLY LOGGED ON THIS BAND",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                    modifier = Modifier.padding(8.dp).fillMaxWidth(), textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                val gridContentValid = !isContestMode || gridRxInput.length == maxGridChars
                if (callSignInput.isNotBlank() && gridContentValid) {
                    val finalRstSent = if (isContestMode) "59" else rstSentInput
                    val finalRstRx = if (isContestMode) "59" else rstRxInput

                    val myPotaEntity = sharedPrefs.getString("pota_entity", "") ?: ""
                    val finalExchangePayload = if (activeContest.contains("Parks on the Air")) "$selectedMode|$myPotaEntity" else selectedMode

                    var finalTimestamp = System.currentTimeMillis()
                    if (manualDateInput.isNotBlank() || manualTimeInput.isNotBlank()) {
                        try {
                            val liveDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
                            val liveTime = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())

                            val targetDate = if (manualDateInput.isNotBlank()) manualDateInput else liveDate
                            val targetTime = if (manualTimeInput.isNotBlank()) manualTimeInput else liveTime

                            val parser = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                            val parsedDate = parser.parse("$targetDate $targetTime")
                            if (parsedDate != null) finalTimestamp = parsedDate.time
                        } catch (e: Exception) {
                            // fall back to current time on parse error
                        }
                    }

                    onSaveContact(
                        LogEntry(
                            callSign = callSignInput,
                            timestamp = finalTimestamp,
                            band = selectedBand,
                            selectedContest = activeContest,
                            rstSent = finalRstSent,
                            rstRx = finalRstRx,
                            serialSent = 0,
                            serialRx = 0,
                            gridRx = gridRxInput,
                            exchangeExtra = finalExchangePayload,
                            gridsquare = liveGrid
                        )
                    )

                    callSignInput = ""
                    gridRxInput = ""
                    rstSentInput = "59"
                    rstRxInput = "59"
                    manualDateInput = ""
                    manualTimeInput = ""
                } else {
                    if (isContestMode) {
                        Toast.makeText(context, "Requires complete ${maxGridChars}-character grid format", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Call Sign is required", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = if (isDuplicateEntry) Color.DarkGray else MaterialTheme.colorScheme.primary)
        ) {
            Text(text = if (isDuplicateEntry) "LOG POTENTIAL DUPE ANYWAY" else if (isContestMode) "LOG CONTEST CONTACT" else "SAVE LOG ENTRY", color = if (isDuplicateEntry) Color.LightGray else Color.Black, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Divider(color = Color.DarkGray)
        Spacer(modifier = Modifier.height(12.dp))

        Text(text = "$activeContest Log (${contactsList.size})", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(contactsList) { contact ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().combinedClickable(
                        onClick = { },
                        onLongClick = {
                            contactActionTarget = contact
                            showActionDialog = true
                        }
                    )
                ) {
                    Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        val parsedExchange = contact.exchangeExtra.split("|")
                        val modeToken = parsedExchange.firstOrNull() ?: "PH"
                        val potaSuffix = if (parsedExchange.size > 1 && parsedExchange[1].isNotBlank()) " • Park: ${parsedExchange[1]}" else ""
                        val gridLabel = if (contact.gridRx.isNotBlank()) " • Grid: ${contact.gridRx}" else ""

                        val timeString = utcFormatter.format(Date(contact.timestamp))

                        Column {
                            Text(text = contact.callSign, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                            Text(text = "$timeString • Band: ${contact.band} • Mode: $modeToken$gridLabel$potaSuffix", fontSize = 11.sp, color = Color.Gray)
                        }
                        if (contact.gridsquare.isNotBlank() && contact.gridsquare != "WAITING") {
                            Text(text = contact.gridsquare.take(4), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        if (showActionDialog && contactActionTarget != null) {
            AlertDialog(
                onDismissRequest = { showActionDialog = false },
                title = { Text("Log Entry: ${contactActionTarget?.callSign}") },
                text = { Text("Would you like to edit or delete this contact?") },
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = Color.White,
                textContentColor = Color.LightGray,
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                        onClick = {
                            contactActionTarget?.let { onDeleteContact(it) }
                            showActionDialog = false
                        }
                    ) { Text("DELETE", color = Color.White, fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        onClick = {
                            val target = contactActionTarget
                            if (target != null) {
                                callSignInput = target.callSign
                                gridRxInput = target.gridRx
                                selectedBand = target.band
                                rstSentInput = target.rstSent
                                rstRxInput = target.rstRx

                                val tokens = target.exchangeExtra.split("|")
                                selectedMode = if (tokens.isNotEmpty() && tokens[0].isNotBlank()) tokens[0] else "PH"

                                val extractDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                                val extractTime = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                                val targetDateObj = Date(target.timestamp)

                                manualDateInput = extractDate.format(targetDateObj)
                                manualTimeInput = extractTime.format(targetDateObj)

                                onDeleteContact(target)
                            }
                            showActionDialog = false
                        }
                    ) { Text("EDIT", color = Color.Black, fontWeight = FontWeight.Bold) }
                }
            )
        }
    }
}

// ----- TOOLBOX MASTER ROUTER & CALCULATORS -----

// ----- TOOLBOX MASTER ROUTER & CALCULATORS -----

@Composable
fun ToolboxMasterRouter(subScreen: String, onNavigate: (String) -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) {
        when (subScreen) {
            "menu" -> {
                Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Top, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "RF TOOLBOX & REFERENCES", fontWeight = FontWeight.Black, color = Color.White, fontSize = 20.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 8.dp))
                    Text(text = "Select a field utility or reference guide.", color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(16.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val tools = listOf(
                            Triple("feedhorn", Icons.Default.Sensors, "Dish Focal Length" to "Calculate optimal f/D ratio"),
                            Triple("coax", Icons.Default.Cable, "Coax Cable Loss" to "Estimate dB loss over cable runs"),
                            Triple("dipole", Icons.Default.Compress, "Dipole Calculator" to "Determine wire lengths per frequency"),
                            Triple("ifcalc", Icons.Default.Calculate, "Transverter IF Math" to "Calculate IF based on LO and Target RF"),
                            Triple("gridmap", Icons.Default.Map, "Maidenhead Grid Map" to "Interactive world grid reference"),
                            Triple("callzones", Icons.Default.PinDrop, "US Call Zones" to "0-9 Call area state lookup"),
                            Triple("cqzones", Icons.Default.Public, "CQ Zones" to "Global CQ zone reference")
                        )

                        items(tools) { (route, icon, textPair) ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth().height(70.dp), onClick = { onNavigate(route) }) {
                                Row(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(icon, contentDescription = textPair.first, tint = Color(0xFF00E676), modifier = Modifier.size(28.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(textPair.first, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                                        Text(textPair.second, color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "dipole" -> DipoleCalculator()
            "coax" -> CoaxLossCalculator()
            "feedhorn" -> FocalLengthCalculator()
            "ifcalc" -> IFTransverterCalculator()
            "gridmap" -> GridMapViewer()
            "callzones" -> USCallZoneReference()
            "cqzones" -> CQZoneReference()
        }
    }
}

@Composable
fun DipoleCalculator() {
    var freqInput by remember { mutableStateOf("") }

    val totalLength = remember(freqInput) {
        val freq = freqInput.toDoubleOrNull()
        if (freq != null && freq > 0) String.format("%.2f ft", 468.0 / freq) else "---"
    }
    val legLength = remember(freqInput) {
        val freq = freqInput.toDoubleOrNull()
        if (freq != null && freq > 0) String.format("%.2f ft", 234.0 / freq) else "---"
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        OutlinedTextField(value = freqInput, onValueChange = { freqInput = it }, label = { Text("Target Frequency (MHz)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("TOTAL WIRE LENGTH", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = totalLength, color = Color(0xFF00E676), fontSize = 42.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(16.dp))
                Text("LENGTH PER LEG (SIDE)", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = legLength, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoaxLossCalculator() {
    var lengthInput by remember { mutableStateOf("") }

    val coaxTypes = listOf("LDF4-50A (1/2\")", "LMR-600", "LMR-400", "LMR-240", "RG-213", "RG-8X", "RG-142", "RG-58", "UT-141 (Semi)")
    var selectedCoax by remember { mutableStateOf(coaxTypes[2]) } // Default LMR-400
    var coaxDropdownExpanded by remember { mutableStateOf(false) }

    val freqBands = listOf("50", "144", "222", "432", "902", "1296")
    var selectedFreq by remember { mutableStateOf(freqBands[1]) }
    var freqDropdownExpanded by remember { mutableStateOf(false) }

    val lossMatrix = mapOf(
        "LDF4-50A (1/2\")" to mapOf("50" to 0.5, "144" to 0.8, "222" to 1.0, "432" to 1.5, "902" to 2.2, "1296" to 2.7),
        "LMR-600" to mapOf("50" to 0.5, "144" to 1.0, "222" to 1.2, "432" to 1.7, "902" to 2.6, "1296" to 3.2),
        "LMR-400" to mapOf("50" to 0.9, "144" to 1.5, "222" to 1.8, "432" to 2.7, "902" to 4.0, "1296" to 4.9),
        "LMR-240" to mapOf("50" to 1.7, "144" to 3.0, "222" to 3.7, "432" to 5.3, "902" to 7.9, "1296" to 9.6),
        "RG-213" to mapOf("50" to 1.6, "144" to 2.8, "222" to 3.5, "432" to 5.2, "902" to 7.8, "1296" to 10.0),
        "RG-8X" to mapOf("50" to 2.5, "144" to 4.7, "222" to 5.8, "432" to 8.5, "902" to 12.5, "1296" to 16.0),
        "RG-142" to mapOf("50" to 2.0, "144" to 3.8, "222" to 4.8, "432" to 7.0, "902" to 10.5, "1296" to 13.0),
        "RG-58" to mapOf("50" to 3.3, "144" to 6.1, "222" to 7.8, "432" to 11.2, "902" to 16.5, "1296" to 24.0),
        "UT-141 (Semi)" to mapOf("50" to 2.5, "144" to 4.5, "222" to 5.7, "432" to 8.0, "902" to 12.0, "1296" to 14.5)
    )

    val estimatedLoss = remember(selectedCoax, selectedFreq, lengthInput) {
        val length = lengthInput.toDoubleOrNull()
        if (length != null && length > 0) {
            val lossPer100 = lossMatrix[selectedCoax]?.get(selectedFreq) ?: 0.0
            String.format("%.2f dB", (lossPer100 / 100.0) * length)
        } else "--- dB"
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ExposedDropdownMenuBox(expanded = coaxDropdownExpanded, onExpandedChange = { coaxDropdownExpanded = !coaxDropdownExpanded }) {
            OutlinedTextField(value = selectedCoax, onValueChange = {}, readOnly = true, label = { Text("Coax Type") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = coaxDropdownExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = coaxDropdownExpanded, onDismissRequest = { coaxDropdownExpanded = false }) {
                coaxTypes.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { selectedCoax = it; coaxDropdownExpanded = false }) }
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(modifier = Modifier.weight(1f)) {
                ExposedDropdownMenuBox(expanded = freqDropdownExpanded, onExpandedChange = { freqDropdownExpanded = !freqDropdownExpanded }) {
                    OutlinedTextField(value = selectedFreq, onValueChange = {}, readOnly = true, label = { Text("Freq (MHz)") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = freqDropdownExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = freqDropdownExpanded, onDismissRequest = { freqDropdownExpanded = false }) {
                        freqBands.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { selectedFreq = it; freqDropdownExpanded = false }) }
                    }
                }
            }
            OutlinedTextField(value = lengthInput, onValueChange = { lengthInput = it }, label = { Text("Length (ft)") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ESTIMATED SIGNAL LOSS", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = estimatedLoss, color = Color(0xFF00E676), fontSize = 42.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun FocalLengthCalculator() {
    var diameterInput by remember { mutableStateOf("") }
    var depthInput by remember { mutableStateOf("") }

    val focalLength = remember(diameterInput, depthInput) {
        val d = diameterInput.toDoubleOrNull()
        val c = depthInput.toDoubleOrNull()
        if (d != null && c != null && c > 0) String.format("%.2f", (d * d) / (16.0 * c)) else "---"
    }

    val fdRatio = remember(diameterInput, focalLength) {
        val d = diameterInput.toDoubleOrNull()
        val f = focalLength.toDoubleOrNull()
        if (d != null && d > 0 && f != null) String.format("%.2f", f / d) else "---"
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = diameterInput, onValueChange = { diameterInput = it }, label = { Text("Dish Diameter (D)") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = depthInput, onValueChange = { depthInput = it }, label = { Text("Dish Depth (c)") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("FOCAL LENGTH (f)", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = focalLength, color = Color(0xFF00E676), fontSize = 42.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(16.dp))
                Text("f / D RATIO", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = fdRatio, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun IFTransverterCalculator() {
    var rfInput by remember { mutableStateOf("") }
    var loInput by remember { mutableStateOf("") }

    val targetIF = remember(rfInput, loInput) {
        val rf = rfInput.toDoubleOrNull()
        val lo = loInput.toDoubleOrNull()
        if (rf != null && lo != null) String.format("%.4f MHz", abs(rf - lo)) else "--- MHz"
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        OutlinedTextField(value = rfInput, onValueChange = { rfInput = it }, label = { Text("Target RF Frequency (MHz)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = loInput, onValueChange = { loInput = it }, label = { Text("Transverter L.O. (MHz)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("RADIO IF TUNE FREQUENCY", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = targetIF, color = Color(0xFF00E676), fontSize = 42.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GridMapViewer() {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                loadUrl("https://k7fry.com/grid/")
            }
        }
    )
}

@Composable
fun USCallZoneReference() {
    val zones = listOf(
        "0" to "CO, IA, KS, MN, MO, NE, ND, SD",
        "1" to "CT, ME, MA, NH, RI, VT",
        "2" to "NJ, NY",
        "3" to "DE, MD, PA",
        "4" to "AL, FL, GA, KY, NC, SC, TN, VA",
        "5" to "AR, LA, MS, NM, OK, TX",
        "6" to "CA",
        "7" to "AZ, ID, MT, NV, OR, UT, WA, WY",
        "8" to "MI, OH, WV",
        "9" to "IL, IN, WI"
    )

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(zones) { (zoneNum, states) ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(text = zoneNum, color = Color(0xFF00E676), fontSize = 32.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(48.dp))
                    Text(text = states, color = Color.White, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun CQZoneReference() {
    val cqZones = listOf(
        "Zone 1" to "Northwestern Zone of NA (AK, YT, NT)",
        "Zone 2" to "Northeastern Zone of NA (QC, NL)",
        "Zone 3" to "Western Zone of NA (BC, CA, OR, WA, ID, NV, AZ)",
        "Zone 4" to "Central Zone of NA (Central US, Central Canada)",
        "Zone 5" to "Eastern Zone of NA (Eastern US)",
        "Zone 6" to "Baja California",
        "Zone 7" to "Central America",
        "Zone 8" to "West Indies",
        "Zone 9" to "Northern South America",
        "Zone 10" to "Western South America",
        "Zone 11" to "Central South America",
        "Zone 12" to "Antarctica (Chilean Sector)"
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("North & South America", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cqZones) { (zoneName, description) ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = zoneName, color = Color(0xFF00E676), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(text = description, color = Color.White, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

// ----- SCATTER TOOLS -----

@Composable
fun ScatterMasterRouter(
    subScreen: String,
    myLat: Double,
    myLon: Double,
    myGrid: String,
    sharedStormGrid: String,
    onSharedGridChanged: (String) -> Unit,
    onNavigate: (String) -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        when (subScreen) {
            "menu" -> {
                Column(modifier = Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "RAIN SCATTER TOOLS", fontWeight = FontWeight.Black, color = Color.White, fontSize = 22.sp, letterSpacing = 1.sp)
                    Text(text = "Select an operation module optimized for field use.", color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(32.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth().height(90.dp), onClick = { onNavigate("map") }) {
                        Row(modifier = Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Map, contentDescription = "Map", tint = Color(0xFF00E676), modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text("Live Radar Map View", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                                Text("Full screen tracking at RainScatter.com", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth().height(90.dp), onClick = { onNavigate("calculator") }) {
                        Row(modifier = Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Calculate, contentDescription = "Calc", tint = Color(0xFF00E676), modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text("Vector Heading Calculator", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                                Text("Determine storm scatter trajectory vectors", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            "map" -> FullScreenRadarPortal(
                onCellCalculated = { computedGrid ->
                    onSharedGridChanged(computedGrid)
                    onNavigate("calculator")
                }
            )
            "calculator" -> VectorHeadingCalculator(
                myLat = myLat,
                myLon = myLon,
                myGrid = myGrid,
                initialStormGrid = sharedStormGrid
            )
        }
    }
}

class GridRoverAppBridge(private val onCellSelected: (String) -> Unit) {
    @JavascriptInterface
    fun onRainCellSelected(grid: String) {
        onCellSelected(grid.uppercase().trim())
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun FullScreenRadarPortal(onCellCalculated: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.builtInZoomControls = true
                settings.displayZoomControls = false

                addJavascriptInterface(GridRoverAppBridge { grid ->
                    scope.launch { onCellCalculated(grid) }
                }, "AndroidBridge")

                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        val mapHookAndGridScript = """
                            (function() {
                                var checkCount = 0;
                                var injectInterval = setInterval(function() {
                                    checkCount++;
                                    if (typeof map !== 'undefined') {
                                        clearInterval(injectInterval);
                                        
                                        if (!window.MaidenheadGridLayer) {
                                            L.MaidenheadGrid = L.GridLayer.extend({
                                                createTile: function(coords) {
                                                    var tile = document.createElement('div');
                                                    tile.style.outline = '1px solid rgba(0, 230, 118, 0.25)';
                                                    tile.style.position = 'relative';
                                                    
                                                    var nwPoint = coords.scaleBy(this.getTileSize());
                                                    var nw = map.unproject(nwPoint, coords.z);
                                                    
                                                    var lat = nw.lat;
                                                    var lon = nw.lng;
                                                    
                                                    if (lon < -180) lon += 360;
                                                    if (lon > 180) lon -= 360;
                                                    if (lat < -90) lat = -90;
                                                    if (lat > 90) lat = 90;
                                                    
                                                    var adjLon = lon + 180.0;
                                                    var adjLat = lat + 90.0;
                                                    
                                                    var fLng = Math.floor(adjLon / 20.0);
                                                    var fLat = Math.floor(adjLat / 10.0);
                                                    var r1Lng = adjLon - (fLng * 20.0);
                                                    var r1Lat = adjLat - (fLat * 10.0);
                                                    var sLng = Math.floor(r1Lng / 2.0);
                                                    var sLat = Math.floor(r1Lat);
                                                    
                                                    var text = String.fromCharCode(65 + fLng) + String.fromCharCode(65 + fLat);
                                                    if (coords.z >= 5) {
                                                        text += String.fromCharCode(48 + sLng) + String.fromCharCode(48 + sLat);
                                                    }
                                                    if (coords.z >= 10) {
                                                        var r2Lng = r1Lng - (sLng * 2.0);
                                                        var r2Lat = r1Lat - sLat;
                                                        var subLng = Math.floor(r2Lng * 12.0);
                                                        var subLat = Math.floor(r2Lat * 24.0);
                                                        text += String.fromCharCode(97 + subLng) + String.fromCharCode(97 + subLat);
                                                    }
                                                    
                                                    var label = document.createElement('div');
                                                    label.style.position = 'absolute';
                                                    label.style.top = '4px';
                                                    label.style.left = '4px';
                                                    label.style.color = 'rgba(0, 230, 118, 0.7)';
                                                    label.style.fontSize = '10px';
                                                    label.style.fontWeight = 'bold';
                                                    label.style.fontFamily = 'monospace';
                                                    label.style.textShadow = '1px 1px 2px black';
                                                    label.innerText = text;
                                                    
                                                    tile.appendChild(label);
                                                    return tile;
                                                }
                                            });
                                            
                                            window.MaidenheadGridLayer = new L.MaidenheadGrid();
                                            window.MaidenheadGridLayer.addTo(map);
                                        }
                                        
                                        map.off('click');
                                        map.on('click', function(e) {
                                            var lat = e.latlng.lat;
                                            var lon = e.latlng.lng;
                                            var adjLon = lon + 180.0;
                                            var adjLat = lat + 90.0;
                                            var fLng = Math.floor(adjLon / 20.0);
                                            var fLat = Math.floor(adjLat / 10.0);
                                            var r1Lng = adjLon - (fLng * 20.0);
                                            var r1Lat = adjLat - (fLat * 10.0);
                                            var sLng = Math.floor(r1Lng / 2.0);
                                            var sLat = Math.floor(r1Lat);
                                            var r2Lng = r1Lng - (sLng * 2.0);
                                            var r2Lat = r1Lat - sLat;
                                            var subLng = Math.floor(r2Lng * 12.0);
                                            var subLat = Math.floor(r2Lat * 24.0);
                                            var gridStr = String.fromCharCode(65 + fLng) + String.fromCharCode(65 + fLat) +
                                                          String.fromCharCode(48 + sLng) + String.fromCharCode(48 + sLat) +
                                                          String.fromCharCode(97 + subLng) + String.fromCharCode(97 + subLat);
                                            if (window.AndroidBridge) {
                                                window.AndroidBridge.onRainCellSelected(gridStr);
                                            }
                                        });
                                    } else if (checkCount > 30) {
                                        clearInterval(injectInterval);
                                    }
                                }, 500);
                            })();
                        """.trimIndent()
                        view?.evaluateJavascript(mapHookAndGridScript, null)
                    }
                }
                loadUrl("https://www.rainscatter.com")
            }
        }
    )
}

@Composable
fun VectorHeadingCalculator(myLat: Double, myLon: Double, myGrid: String, initialStormGrid: String) {
    var stationGridInput by remember { mutableStateOf("") }
    var stormGridInput by remember { mutableStateOf(initialStormGrid) }
    var directHeading by remember { mutableStateOf("---°") }
    var scatterHeading by remember { mutableStateOf("---°") }
    var directDistance by remember { mutableStateOf("--- km") }

    val triggerCalculation = remember(myLat, myLon, stationGridInput, stormGridInput) {
        {
            val (stLat, stLon) = parseMaidenhead(stationGridInput)
            val (cellLat, cellLon) = parseMaidenhead(stormGridInput)
            if (stLat != null && stLon != null) {
                directHeading = "${calculateBearing(myLat, myLon, stLat, stLon)}°"
                directDistance = "${calculateDistance(myLat, myLon, stLat, stLon)} km"
            } else { directHeading = "---°"; directDistance = "--- km" }
            if (cellLat != null && cellLon != null) {
                scatterHeading = "${calculateBearing(myLat, myLon, cellLat, cellLon)}°"
            } else { scatterHeading = "---°" }
        }
    }

    LaunchedEffect(initialStormGrid) {
        stormGridInput = initialStormGrid
        triggerCalculation()
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("GRID INTERSECTION PROFILE", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
        OutlinedTextField(value = stationGridInput, onValueChange = { stationGridInput = it.uppercase(); triggerCalculation() }, label = { Text("Distant Station Grid") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = stormGridInput, onValueChange = { stormGridInput = it.uppercase(); triggerCalculation() }, label = { Text("Rain Cell Core Grid") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(modifier = Modifier.height(12.dp)); Divider(color = Color.DarkGray); Spacer(modifier = Modifier.height(12.dp))
        Text("OPTIMAL RADAR TRAJECTORY", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("AIM DISH AT RAIN CELL CORE", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = scatterHeading, color = Color(0xFF00E676), fontSize = 54.sp, fontWeight = FontWeight.Black)
                Text("My Position: $myGrid", color = Color.DarkGray, fontSize = 12.sp)
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("DIRECT BEARING", color = Color.Gray, fontSize = 10.sp)
                    Text(directHeading, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STATION DISTANCE", color = Color.Gray, fontSize = 10.sp)
                    Text(directDistance, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ----- HELPER FUNCTIONS -----

fun calculateLiveScore(logs: List<LogEntry>, contest: String, myClass: String): Pair<String, String> {
    if (logs.isEmpty()) return Pair("0", "0 points\n0 mults")

    if (contest.contains("General") || contest.contains("Parks on the Air")) {
        val totalQSOs = logs.size
        val trackingMetrics = if (contest.contains("Parks on the Air")) {
            val uniqueParksCount = logs.map { it.exchangeExtra.split("|").getOrNull(1) ?: "" }.filter { it.isNotBlank() }.distinct().size
            "Total QSOs: $totalQSOs\nUnique Parks: $uniqueParksCount"
        } else {
            "Total logged elements: $totalQSOs"
        }
        return Pair(totalQSOs.toString(), trackingMetrics)
    }

    val amIRover = myClass.contains("Rover")

    if (contest.contains("10 GHz")) {
        var totalDistancePoints = 0.0
        val uniqueBandsWorked = logs.groupBy { it.band }
        var bountyQsoPoints = 0

        for ((band, bandLogs) in uniqueBandsWorked) {
            val factor = if (band.contains("1.2cm")) 2 else 1
            val uniqueCallsCount = bandLogs.map { it.callSign }.distinct().size
            bountyQsoPoints += (uniqueCallsCount * 100)

            for (qso in bandLogs) {
                val center1 = parseMaidenhead(qso.gridsquare)
                val center2 = parseMaidenhead(qso.gridRx)
                if (center1.first != null && center1.second != null && center2.first != null && center2.second != null) {
                    val dLat = Math.toRadians(center2.first!! - center1.first!!)
                    val dLon = Math.toRadians(center2.second!! - center1.second!!)
                    val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(center1.first!!)) * cos(Math.toRadians(center2.first!!)) * sin(dLon / 2).pow(2)
                    val km = 6371.0 * (2 * atan2(sqrt(a), sqrt(1 - a)))
                    totalDistancePoints += (km * factor)
                }
            }
        }
        val finalScore = (totalDistancePoints.roundToInt() + bountyQsoPoints)
        return Pair(String.format("%,d", finalScore), "Distance Pts: ${totalDistancePoints.roundToInt()}\nBounty Pts: $bountyQsoPoints")
    }

    if (contest.contains("CQ World Wide")) {
        var qsoPoints = 0
        val uniqueGrids = mutableSetOf<String>()
        for (qso in logs) {
            val cleanGrid = qso.gridRx.take(4)
            if (cleanGrid.length == 4) uniqueGrids.add(cleanGrid)
            if (qso.band.contains("6m")) qsoPoints += 1
            if (qso.band.contains("2m")) qsoPoints += 2
        }
        return Pair(String.format("%,d", qsoPoints * uniqueGrids.size), "QSO Pts: $qsoPoints\nCombined Grids: ${uniqueGrids.size}")
    }

    var qsoPoints = 0
    val bandMultipliersMap = mutableMapOf<String, MutableSet<String>>()
    val myActivationGrids = mutableSetOf<String>()
    val isJanuaryContest = contest.contains("January")

    for (qso in logs) {
        val band = qso.band.lowercase()
        val theirGrid = qso.gridRx.take(4)
        myActivationGrids.add(qso.gridsquare.take(4))

        when {
            band.contains("6m") || band.contains("2m") -> qsoPoints += 1
            band.contains("1.25m") || band.contains("70cm") -> qsoPoints += 2
            band.contains("33cm") || band.contains("23cm") -> qsoPoints += if (isJanuaryContest) 4 else 3
            else -> qsoPoints += if (isJanuaryContest) 8 else 4
        }
        if (theirGrid.length == 4) {
            bandMultipliersMap.getOrPut(band) { mutableSetOf() }.add(theirGrid)
        }
    }

    val totalBandMultipliers = bandMultipliersMap.values.sumOf { it.size }
    val finalMultiplier = if (amIRover) totalBandMultipliers + myActivationGrids.size else totalBandMultipliers
    val breakdownLabel = if (amIRover) "QSO Pts: $qsoPoints\nMults: $totalBandMultipliers + ${myActivationGrids.size} Grid Stops" else "QSO Pts: $qsoPoints\nTotal Band-Mults: $totalBandMultipliers"

    return Pair(String.format("%,d", qsoPoints * finalMultiplier), breakdownLabel)
}

fun parseMaidenhead(grid: String): Pair<Double?, Double?> {
    val clean = grid.trim().uppercase()
    if (clean.length < 4) return Pair(null, null)
    try {
        val lonField = clean[0] - 'A'; val latField = clean[1] - 'A'
        val lonSquare = clean[2] - '0'; val latSquare = clean[3] - '0'
        var lon = (lonField * 20.0) - 180.0 + (lonSquare * 2.0)
        var lat = (latField * 10.0) - 90.0 + latSquare
        if (clean.length >= 6) {
            val lonSub = clean[4].lowercaseChar() - 'a'; val latSub = clean[5].lowercaseChar() - 'a'
            lon += (lonSub * (2.0 / 24.0)) + (1.0 / 24.0)
            lat += (latSub * (1.0 / 24.0)) + (0.5 / 24.0)
        } else { lon += 1.0; lat += 0.5 }
        return Pair(lat, lon)
    } catch (e: Exception) { return Pair(null, null) }
}

fun calculateBearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
    val dLon = Math.toRadians(lon2 - lon1)
    val rLat1 = Math.toRadians(lat1); val rLat2 = Math.toRadians(lat2)
    val y = sin(dLon) * cos(rLat2)
    val x = cos(rLat1) * sin(rLat2) - sin(rLat1) * cos(rLat2) * cos(dLon)
    return ((Math.toDegrees(atan2(y, x)) + 360.0) % 360.0).roundToInt()
}

fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
    val dLat = Math.toRadians(lat2 - lat1); val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
    return (6371.0 * (2 * atan2(sqrt(a), sqrt(1 - a)))).roundToInt()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsTabScreen(contactsList: List<LogEntry>, activeContest: String, onContestChanged: (String) -> Unit) {
    val context = LocalContext.current
    val sharedPrefs = remember { context.getSharedPreferences("GridRoverPrefs", Context.MODE_PRIVATE) }

    var stationCallSign by remember { mutableStateOf(sharedPrefs.getString("callsign", "") ?: "") }
    var potaEntityInput by remember { mutableStateOf(sharedPrefs.getString("pota_entity", "") ?: "") }
    var rigConfig by remember { mutableStateOf(sharedPrefs.getString("rig", "") ?: "") }
    var clubNameInput by remember { mutableStateOf(sharedPrefs.getString("club", "") ?: "") }
    var currentSelectedContest by remember { mutableStateOf(sharedPrefs.getString("active_contest", "ARRL June VHF Contest") ?: "ARRL June VHF Contest") }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val standardClassOptions = remember(currentSelectedContest) { getFilteredClasses(currentSelectedContest) }
    var selectedStandardClass by remember(currentSelectedContest) {
        mutableStateOf(sharedPrefs.getString("class_$currentSelectedContest", standardClassOptions.first()) ?: standardClassOptions.first())
    }
    var standardClassDropdownExpanded by remember { mutableStateOf(false) }

    val masterContestsList = listOf(
        "General Logging",
        "Parks on the Air (POTA)",
        "ARRL June VHF Contest",
        "ARRL September VHF Contest",
        "ARRL January VHF Contest",
        "ARRL 222 MHz and Up Distance Contest",
        "ARRL 10 GHz and Up Contest",
        "CQ World Wide VHF Contest"
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("STATION CONFIGURATION", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column {
                    Text("Selected Configuration Mode", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    ExposedDropdownMenuBox(expanded = dropdownExpanded, onExpandedChange = { dropdownExpanded = !dropdownExpanded }) {
                        OutlinedTextField(
                            value = currentSelectedContest, onValueChange = {}, readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                        ExposedDropdownMenu(expanded = dropdownExpanded, onDismissRequest = { dropdownExpanded = false }) {
                            masterContestsList.forEach { contestOption ->
                                DropdownMenuItem(text = { Text(contestOption) }, onClick = {
                                    currentSelectedContest = contestOption; dropdownExpanded = false
                                    sharedPrefs.edit().putString("active_contest", contestOption).apply()
                                    onContestChanged(contestOption)
                                })
                            }
                        }
                    }
                }
                Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 4.dp))
                OutlinedTextField(value = stationCallSign, onValueChange = { stationCallSign = it.uppercase(); sharedPrefs.edit().putString("callsign", it.uppercase()).apply() }, label = { Text("Operator Call Sign") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                Column {
                    Text("Operating Role / Entry Class", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    ExposedDropdownMenuBox(expanded = standardClassDropdownExpanded, onExpandedChange = { standardClassDropdownExpanded = !standardClassDropdownExpanded }) {
                        OutlinedTextField(value = selectedStandardClass, onValueChange = {}, readOnly = true, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = standardClassDropdownExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                        ExposedDropdownMenu(
                            expanded = standardClassDropdownExpanded,
                            onDismissRequest = { standardClassDropdownExpanded = false }
                        ) {
                            standardClassOptions.forEach { classOption ->
                                DropdownMenuItem(
                                    text = { Text(classOption) },
                                    onClick = {
                                        selectedStandardClass = classOption
                                        standardClassDropdownExpanded = false
                                        sharedPrefs.edit().putString("class", classOption).putString("class_$currentSelectedContest", classOption).apply()
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(value = potaEntityInput, onValueChange = { potaEntityInput = it.uppercase(); sharedPrefs.edit().putString("pota_entity", it.uppercase()).apply() }, label = { Text("My POTA Park Reference (e.g., K-0001)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = clubNameInput, onValueChange = { clubNameInput = it; sharedPrefs.edit().putString("club", it).apply() }, label = { Text("Affiliated Club Name (Optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = rigConfig, onValueChange = { gridConfig -> rigConfig = gridConfig; sharedPrefs.edit().putString("rig", gridConfig).apply() }, label = { Text("Power / Rig Setup Info") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

                if (contactsList.isNotEmpty()) {
                    Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "LOG MANAGER (${activeContest} Contains ${contactsList.size} Records)", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { exportLogToADIF(context, contactsList, activeContest) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)), modifier = Modifier.weight(1f)) { Text("EXPORT ADIF", color = Color.Black, fontWeight = FontWeight.Bold) }
                        if (!activeContest.contains("General") && !activeContest.contains("Parks on the Air")) {
                            Button(onClick = { exportLogToCabrillo(context, contactsList, activeContest) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)), modifier = Modifier.weight(1f)) { Text("EXPORT CABRILLO", color = Color.Black, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}

fun getFilteredClasses(contestName: String): List<String> {
    return when {
        contestName.contains("Parks on the Air") -> listOf("Activator", "Hunter")
        contestName.contains("General") -> listOf("Home Station", "Portable", "Mobile", "QRP")
        else -> listOf("Rover", "Limited Rover", "Ultralight Rover", "Single-Op Portable", "Single-Op Low Power", "Single-Op High Power", "Multi-Op")
    }
}

fun getFilteredBands(contestName: String): List<String> {
    return when {
        contestName.contains("General") || contestName.contains("Parks on the Air") ->
            listOf("160m", "80m", "40m", "30m", "20m", "17m", "15m", "12m", "10m", "6m", "2m", "1.25m", "70cm")
        contestName.contains("10 GHz") -> listOf("3cm", "1.2cm", "Light")
        contestName.contains("222 MHz") -> listOf("1.25m", "70cm", "33cm", "23cm", "13cm", "9cm", "5cm", "3cm", "1.2cm")
        contestName.contains("CQ World Wide") -> listOf("6m", "2m")
        else -> listOf("6m", "2m", "1.25m", "70cm", "33cm", "23cm", "13cm", "9cm", "5cm", "3cm", "1.2cm")
    }
}

fun exportLogToADIF(context: Context, logs: List<LogEntry>, contestName: String) {
    val sharedPrefs = context.getSharedPreferences("GridRoverPrefs", Context.MODE_PRIVATE)
    val myCall = sharedPrefs.getString("callsign", "ROVER-STATION") ?: "ROVER-STATION"
    val myClub = sharedPrefs.getString("club", "") ?: ""
    val dateFormatter = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    val timeFormatter = SimpleDateFormat("HHmmss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

    val adifBuilder = StringBuilder().append("Generated by Odyssey Logger\n<ADIF_VER:5>2.2.7\n<EOH>\n\n")
    for (entry in logs) {
        val tokens = entry.exchangeExtra.split("|")
        val mode = if (tokens.isNotEmpty() && tokens[0].isNotBlank()) tokens[0] else "PH"
        val explicitPark = if (tokens.size > 1) tokens[1] else ""

        adifBuilder.append("<CALL:${entry.callSign.length}>${entry.callSign} ")
            .append("<QSO_DATE:8>${dateFormatter.format(Date(entry.timestamp))} ")
            .append("<TIME_ON:6>${timeFormatter.format(Date(entry.timestamp))} ")
            .append("<BAND:${entry.band.length}>${entry.band.lowercase()} ")
            .append("<MODE:${mode.length}>$mode ")
            .append("<RST_SENT:${entry.rstSent.length}>${entry.rstSent} ")
            .append("<RST_RCVD:${entry.rstRx.length}>${entry.rstRx} ")
            .append("<STATION_CALLSIGN:${myCall.length}>$myCall ")

        if (entry.gridRx.isNotBlank()) adifBuilder.append("<GRIDSQUARE:${entry.gridRx.length}>${entry.gridRx} ")
        if (entry.gridsquare.isNotBlank() && entry.gridsquare != "WAITING") adifBuilder.append("<MY_GRIDSQUARE:${entry.gridsquare.length}>${entry.gridsquare} ")
        if (explicitPark.isNotBlank()) adifBuilder.append("<SIG:4>POTA <SIG_INFO:${explicitPark.length}>$explicitPark ")
        if (myClub.isNotBlank()) adifBuilder.append("<CLUB:${myClub.length}>$myClub ")

        adifBuilder.append("<EOR>\n")
    }
    writeAndShareFile(context, adifBuilder.toString(), "${contestName.replace(" ", "_")}_Log.adi")
}

fun exportLogToCabrillo(context: Context, logs: List<LogEntry>, contestName: String) {
    val sharedPrefs = context.getSharedPreferences("GridRoverPrefs", Context.MODE_PRIVATE)
    val myCall = sharedPrefs.getString("callsign", "N0CALL") ?: "N0CALL"
    val myClub = sharedPrefs.getString("club", "NONE") ?: "NONE"
    val myClass = sharedPrefs.getString("class", "ROVER") ?: "ROVER"
    val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    val timeFormatter = SimpleDateFormat("HHmm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

    val cabrilloBuilder = StringBuilder()
        .append("START-OF-LOG: 3.0\nCREATED-BY: Odyssey Logger\n")
        .append("CONTEST: ${if(contestName.contains("June")) "ARRL-VHF-JUN" else if(contestName.contains("September")) "ARRL-VHF-SEP" else if(contestName.contains("January")) "ARRL-VHF-JAN" else "ARRL-VHF"}\n")
        .append("CALLSIGN: $myCall\nCLUB: $myClub\nCATEGORY-OPERATOR: SINGLE-OP\n")
        .append("CATEGORY-STATION: ${myClass.uppercase()}\nEND-OF-HEADER\n\n")

    for (entry in logs) {
        val mode = entry.exchangeExtra.split("|").firstOrNull() ?: "PH"
        cabrilloBuilder.append("QSO: ").append(getCabrilloBandIdentifier(entry.band).padEnd(5)).append(" ")
            .append(mode.padEnd(2)).append(" ")
            .append(dateFormatter.format(Date(entry.timestamp))).append(" ")
            .append(timeFormatter.format(Date(entry.timestamp))).append(" ")
            .append(myCall.padEnd(10)).append(entry.gridsquare.take(4).padEnd(6)).append(" ")
            .append(entry.callSign.padEnd(10)).append(entry.gridRx.take(4).padEnd(6)).append("\n")
    }
    cabrilloBuilder.append("END-OF-LOG:\n")
    writeAndShareFile(context, cabrilloBuilder.toString(), "${contestName.replace(" ", "_")}_Log.cbr")
}

fun getCabrilloBandIdentifier(band: String): String = when(band.lowercase()) {
    "6m" -> "50" ; "2m" -> "144" ; "1.25m" -> "222" ; "70cm" -> "432" ; "33cm" -> "902" ; "23cm" -> "1.2G" ; "3cm" -> "10G" ; "1.2cm" -> "24G" ; else -> band.uppercase()
}

fun writeAndShareFile(context: Context, data: String, fileName: String) {
    try {
        val cacheDir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
        val logFile = File(cacheDir, fileName).apply { FileWriter(this).use { it.write(data) } }

        val fileUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", logFile)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            // Changed to */* to force Android to show File Managers and Google Drive
            type = "*/*"
            putExtra(Intent.EXTRA_STREAM, fileUri)
            // Added EXTRA_TITLE so Google Drive automatically populates the correct file name
            putExtra(Intent.EXTRA_TITLE, fileName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Save or Share Log File..."))
    } catch (e: Exception) {
        Toast.makeText(context, "Export Failed", Toast.LENGTH_SHORT).show()
    }
}

fun convertToGridSquare(lat: Double, lon: Double): String {
    val adjustedLon = lon + 180.0
    val adjustedLat = lat + 90.0
    val fieldLng = (adjustedLon / 20.0).toInt()
    val fieldLat = (adjustedLat / 10.0).toInt()
    val rem1Lng = adjustedLon - (fieldLng * 20.0)
    val rem1Lat = adjustedLat - (fieldLat * 10.0)
    val squareLng = (rem1Lng / 2.0).toInt()
    val squareLat = rem1Lat.toInt()
    val rem2Lng = rem1Lng - (squareLng * 2.0)
    val rem2Lat = rem1Lat - squareLat
    val subLng = floor(rem2Lng * 12.0).toInt()
    val subLat = floor(rem2Lat * 24.0).toInt()
    val rem3Lng = rem2Lng - (subLng / 12.0)
    val rem3Lat = rem2Lat - (subLat / 24.0)
    val extLng = floor(rem3Lng * 120.0).toInt()
    val extLat = floor(rem3Lat * 240.0).toInt()

    return "${('A'.code + fieldLng).toChar()}${('A'.code + fieldLat).toChar()}" +
            "${('0'.code + squareLng).toChar()}${('0'.code + squareLat).toChar()}" +
            "${('a'.code + subLng).toChar()}${('a'.code + subLat).toChar()}" +
            "${('0'.code + extLng).toChar()}${('0'.code + extLat).toChar()}"
}