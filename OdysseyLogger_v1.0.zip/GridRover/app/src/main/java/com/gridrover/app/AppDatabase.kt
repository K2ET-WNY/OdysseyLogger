package com.gridrover.app

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * The Physical Filing Cabinet:
 * This initializes the local storage file on the phone's hard drive.
 */
@Database(entities = [LogEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun logDao(): LogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            // If a cabinet already exists, use it. Otherwise, physically build it on the disk.
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gridrover_database" // The actual offline file name
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}