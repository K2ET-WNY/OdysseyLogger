package com.gridrover.app

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "log_entries")
data class LogEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val callSign: String,
    val timestamp: Long,
    val band: String,
    val selectedContest: String,
    val rstSent: String = "59",
    val rstRx: String = "59",
    val serialSent: Int = 0,
    val serialRx: Int = 0,
    val gridRx: String = "",
    val exchangeExtra: String = "",
    val gridsquare: String
)